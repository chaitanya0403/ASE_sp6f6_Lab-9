describe('RedditCtrl', function(){
    var scope;
    
    beforeEach(module('myreddit'));
    var $controller;
    beforeEach(inject(function(_$controller_) {
        $controller = _$controller_;
    }));
    it('should be running', function(){
      expect(scope.stories.(child.data.thumbnail)).toEqual(story.thumbnail);  
    });
});
describe('RedditCtrl', function(){
    var scope;
    
    beforeEach(module('myreddit'));
    var $controller;
    beforeEach(inject(function(_$controller_) {
        $controller = _$controller_;
    }));
    it('should be running', function(){
      expect(scope.stories.(child.data.title)).toEqual(story.title);  
    });
});
describe('RedditCtrl', function(){
    var scope;
    
    beforeEach(module('myreddit'));
    var $controller;
    beforeEach(inject(function(_$controller_) {
        $controller = _$controller_;
    }));
    it('should be running', function(){
      expect(scope.stories.(child.data.url)).toEqual(story.url);  
    });
});